## v0.12.0:

* [COOK-2213] - iptables disabled recipe

## v0.11.0:

* [COOK-1883] - add perl package so rebuild script works

## v0.10.0:

* [COOK-641] - be able to save output on rhel-family
* [COOK-655] - use a template from other cookbooks

## v0.9.3:

* Current public release.

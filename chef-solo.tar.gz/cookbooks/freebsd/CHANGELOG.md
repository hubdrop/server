## v0.1.0:

### Bug

- [COOK-2568]: FreeBSD cookbook throws Error in runtime

## v0.0.6:

* [COOK-1605] - `freebsd_port_options` always notifies

## v0.0.4:

* [COOK-1430] - resolve foodcritic warnings; LWRP now defines default action

## v0.0.2:

* [COOK-1084] - fix older version building from ports

## v0.0.1:

* [COOK-1074] - initial release

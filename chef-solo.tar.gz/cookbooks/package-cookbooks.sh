tar zcvf chef-solo.tar.gz ../cookbooks --exclude .git chef-solo.tar.gz
git add chef-solo.tar.gz
git commit -m 'HubDrop: Cookbook Package Updated.'
git push
